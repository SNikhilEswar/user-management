import { createContext, useContext, useEffect, useState } from 'react';
import axios from 'axios';
import {APIURL} from '../../constant';
import { toast } from 'react-toastify';


const ApiContext = createContext();

const handleSuccess = (value) => {
  // Assuming you have the ID from the POST API response
  toast.success(value);
};

// const handleError = (value) => {
//   // Assuming you have the ID from the POST API response
//   toast.error("Something Went Wrong");
// };


export const ApiProvider = ({ children }) => {
  const [rows, setRows] = useState([]);
  const [autocomplete, setAutoComplete] = useState([]);
  const [selected, setSelected] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const fetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(`${APIURL}`);
      setRows(response.data);
      if(response.data.length > 0) {
        const combinedDataArray = response.data.map(user => ({ name: `${user.firstName} ${user.lastName}`, _id: user._id }))
        .concat(response.data.map(user => ({ name: user.uniqueId, _id: user._id })));
         setAutoComplete(combinedDataArray);
      }
    } catch (err) {
      setError(err);
      setRows([]);
    } finally {
      setLoading(false);
    }
  };

  const deletedFetchData = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(`${APIURL}/deleted`);
      setRows(response.data);
      if(response.data.length > 0) {
        const combinedDataArray = response.data.map(user => ({ name: `${user.firstName} ${user.lastName}`, _id: user._id }))
        .concat(response.data.map(user => ({ name: user.uniqueId, _id: user._id })));
         setAutoComplete(combinedDataArray);
      }
    } catch (err) {
      setError(err);
      setRows([]);
    } finally {
      setLoading(false);
    }
  };


  const fetchSingleData = async (id) => {
    setLoading(true);
    setError(null);
    try {
      const response = await axios.get(`${APIURL}/getUser/${id}`);
      setRows([response.data]);
    } catch (err) {
      setError(err);
      setRows([]);
    } finally {
      setLoading(false);
    }
  };

  const deleteAllUsers = async (deleteUsers,type,handleCloseDelete ) => {
    setLoading(true);
    setError(null);
    console.log(type);
    try {
      await axios.put(`${APIURL}/deleteSelected`,deleteUsers);
      if(type == "single") {
        handleCloseDelete();
        handleSuccess('User Deleted Successfully');
        fetchData();
      } else if(type == "enableAll"){
        setSelected([]);
        handleSuccess(`All Users Enabled Successfully`);
        deletedFetchData();
      } else if(type === "enableSingle") {
        handleSuccess(`User Enabled Successfully`);
        deletedFetchData();
      }
      else {
        setSelected([]);
        handleSuccess(`All Users Deleted Successfully`);
        fetchData();
      }
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
    deletedFetchData();
  }, []);


  const postApiData = async (requestData,setSubmitting,handleClose) => {
    setLoading(true);
    setError(null);
    try {
     const response =  await axios.post(`${APIURL}/createUser`,requestData);
      // After successfully creating the post, re-fetch the data to update the UI
      fetchData();
      setSubmitting();
      handleSuccess(`ID ${response.data._id} created successfully!`);
      handleClose();
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  };

  const putApiData = async (requestData,id,setSubmitting,handleClose) => {
    setLoading(true);
    setError(null);
    try {
      await axios.put(`${APIURL}/updateUser/${id}`,requestData);
      // After successfully creating the post, re-fetch the data to update the UI
      fetchData();
      setSubmitting();
      handleSuccess(`ID ${id} Edited successfully!`);
      handleClose();
    } catch (err) {
      setError(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <ApiContext.Provider value={{ rows, setRows,fetchData,deletedFetchData,autocomplete,fetchSingleData,selected,setSelected,deleteAllUsers, loading, error, postApiData,putApiData }}>
      {children}
    </ApiContext.Provider>
  );
};

export const useApi = () => {
  const context = useContext(ApiContext);
  if (!context) {
    throw new Error('useApi must be used within an ApiProvider');
  }
  return context;
};






















// import { createContext, useReducer, useContext, useEffect } from 'react';
// import {APIURL} from '../../constant';
// // Define initial state
// const initialState = {
//     rows: [],
//     loading: false,
//     error: null,
//   };

//   // Define action types
// const ActionTypes = {
//     FETCH_START: 'FETCH_START',
//     FETCH_SUCCESS: 'FETCH_SUCCESS',
//     FETCH_ERROR: 'FETCH_ERROR',
//   };

//   // Define reducer function
// const reducer = (state, action) => {
//     switch (action.type) {
//       case ActionTypes.FETCH_START:
//         return { ...state, loading: true, error: null };
//       case ActionTypes.FETCH_SUCCESS:
//         return { ...state, loading: false, rows: action.payload };
//       case ActionTypes.FETCH_ERROR:
//         return { ...state, loading: false, error: action.payload };
//       default:
//         return state;
//     }
//   };
  
//   // Create the context
// const ApiContext = createContext();

// // Create the provider component
// const ApiProvider = ({ children }) => {
//     const [state, dispatch] = useReducer(reducer, initialState);

//     // Function to fetch data from the API
//   const fetchData = async () => {
//     dispatch({ type: ActionTypes.FETCH_START });
//     try {
//       // Make your API call here
//       const response = await fetch(APIURL);
//       const data = await response.json();
//       dispatch({ type: ActionTypes.FETCH_SUCCESS, payload: data });
//     } catch (error) {
//       dispatch({ type: ActionTypes.FETCH_ERROR, payload: error.message });
//     }
//   };

//     // Use useEffect to fetch data when the component mounts
//     useEffect(() => {
//         fetchData();
//       }, []);

//       return (
//         <ApiContext.Provider value={{ ...state, fetchData }}>
//           {children}
//         </ApiContext.Provider>
//       );
// }

// // Create a custom hook to use the context
// const useApi = () => {
//     const context = useContext(ApiContext);
//     if (!context) {
//       throw new Error('useApi must be used within an ApiProvider');
//     }
//     return context;
//   };
  
//   export { ApiProvider, useApi };